Questions

How would you implement the ability for users to edit/delete their own posts, but not someone else's?
    Since we assume nicknames are globally unique, even though no such checks are inplace. I would check the nickname of the user, and allow this functionality only then. 
    A better solution would be to also store the user id from the anonymous user with the message, and check that in comparison with the currently logged in user.

In the current implementation, if two users choose the nickname "bob", they will appear as if there is only one user with that nickname. How would you implement globally unique user IDs, and how would you enforce it? Can users pick their own nicknames then? 
    One way could be to check the database and check if the chosen nickname is in use, and have the user chose something else if it is taken. Another way would be to add a unique number combination at the end of all nicknames.

Is it possible with Firebase to implement the ability for users to login with their FB, Google, Github identities? Can you link it with the previously established anonymous identity? 
    Yes, the documentation covers these scenarios.

Current implementation requires background Service to monitor periodically for updates. This makes the app real-time ONLY when the foreground app is running. How would you possibly make it such that instead of PULL-mode, the PUSH mode is used, and notifications are done in real-time also? Hint: check Messaging, and PULL- vs. PUSH-models for data synchronisations.
    Not sure about this one, but maybe by using something like Firebase Cloud Messaging (FCM) to send notifications to the users of the app?

