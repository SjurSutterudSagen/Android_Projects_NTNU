package com.example.sjur.imt3673_lab4_sss;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentFriendsList extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    private String TAG = "LAB4_CHAT";
    private ListView lv_usernames;
    private ArrayList<String> usernamesList;
    private SwipeRefreshLayout mSwipeLayout;
    private ArrayAdapter<String> adapter;

    private FirebaseDatabase mDatabase;
    private DatabaseReference mDatabaseRefUsers;

    User user;

    public FragmentFriendsList() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View fragmentView = inflater.inflate(
                R.layout.friends_list_fragment,
                container,
                false);
        lv_usernames = (ListView)fragmentView.findViewById(R.id.lv_friends_list_view);

        //  get usernames from db and update listview with usernames
        mDatabase = FirebaseDatabase.getInstance();
        mDatabaseRefUsers = mDatabase.getReference("users");
        usernamesList = new ArrayList<>();

        adapter = new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_list_item_1,
                usernamesList);
        lv_usernames.setAdapter(adapter);

        updateUserList();

        //  On click listener for the userlist items
        lv_usernames.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String specificUsername = usernamesList.get(position);
                Intent intent = new Intent (getActivity(), SpecificUserMessagesActivity.class);
                intent.putExtra("specificUserMessagesToDisplay", specificUsername);
                startActivity (intent);
            }
        });

        //  pull-down refresh to reload the feed
        mSwipeLayout = (SwipeRefreshLayout) fragmentView.findViewById(R.id.userSwipeRefreshLayout);
        mSwipeLayout.setOnRefreshListener((SwipeRefreshLayout.OnRefreshListener) this);

        return fragmentView;
    }

    @Override
    public void onRefresh() {
        updateUserList();
        mSwipeLayout.setRefreshing(false);
    }

    public void updateUserList() {

        // Attach a listener to read the data at users reference
        mDatabaseRefUsers.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                usernamesList.clear();
                for(DataSnapshot ds: dataSnapshot.getChildren()) {
                    user = ds.getValue(User.class);
                    usernamesList.add("" + user.getUsername());
                }

                //  Sorting the usernamesList
                Collections.sort(usernamesList, new Comparator<String>() {
                    @Override
                    public int compare(String s1, String s2) {
                        return s1.compareToIgnoreCase(s2);
                    }
                });
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("FriendsFragment: The read from users failed: " + databaseError.getCode());
            }
        });
    }
}
