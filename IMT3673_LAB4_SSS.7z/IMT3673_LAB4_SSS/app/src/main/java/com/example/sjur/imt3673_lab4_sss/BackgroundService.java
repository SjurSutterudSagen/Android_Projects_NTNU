package com.example.sjur.imt3673_lab4_sss;

import android.app.IntentService;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class BackgroundService extends IntentService implements ValueEventListener {

    private String TAG = "LAB4_CHAT";
    private NotificationManager notManager;
    private NotificationCompat.Builder notBuilder;
    private PendingIntent backToActIntent;
    private SharedPreferences settings;
    private int lastMsgPos;

    public BackgroundService() {
        super("BackgroundService");
    }

    /**
     * Creates a notification when an intent is received.
     * Adds data from the last message in the notification.
     * @param intent
     */
    @Override
    protected void onHandleIntent(Intent intent) {
        //Log.v(TAG, "BackgroundService: onHandleIntent");
        FirebaseDatabase mDatabase = FirebaseDatabase.getInstance();
        DatabaseReference mDatabaseRefMsg = mDatabase.getReference("messages");
        this.notManager = (NotificationManager) getSystemService(Service.NOTIFICATION_SERVICE);

        //  Check for android version: Oreo needs a notification channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(
                    "New message!",
                    "There is a new message in the chat.",
                    NotificationManager.IMPORTANCE_DEFAULT);
            this.notManager.createNotificationChannel(notificationChannel);
            this.notBuilder = new NotificationCompat.Builder(this, notificationChannel.getId());
        } else {

            //noinspection deprecation
            this.notBuilder = new NotificationCompat.Builder(this);
        }

        //  Intent for relaunching the app from the notification
        this.backToActIntent = PendingIntent.getActivity(
                this,
                0,
                new Intent(this, ChatActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT
        );

        //  Start event listener that runs only once, checking for new messages
        settings = PreferenceManager.getDefaultSharedPreferences(this);
        lastMsgPos = settings.getInt("last_message_seen", 0);
        mDatabaseRefMsg
                .orderByChild("timestamp")
                .startAt(lastMsgPos + 1)
                .addListenerForSingleValueEvent(this);
    }

    /**
     * Builds and displays the notification
     * @param msg Message object of the latest message
     */
    private void buildAndShowNotification(Message msg) {
        this.notBuilder
                .setSmallIcon(R.drawable.ic_forum_black_48dp)
                .setContentTitle(msg.getUsername())
                .setContentText(msg.getMessage())
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(this.backToActIntent);
        this.notManager.notify(1, this.notBuilder.build());
    }

    /**
     * Displays a notification when there is a change in the db
     * @param dataSnapshot Collection of message objects
     */
    @Override
    public void onDataChange(DataSnapshot dataSnapshot) {
        //Log.v(TAG, "BackgroundService: onDataChange");
        for (DataSnapshot ds : dataSnapshot.getChildren()) {
            Message msg = ds.getValue(Message.class);
            buildAndShowNotification(msg);
        }
    }

    /**
     * Not used
     * @param databaseError
     */
    @Override
    public void onCancelled(DatabaseError databaseError) {
        Log.v(TAG, "BackgroundService: onCancelled");
    }
}
