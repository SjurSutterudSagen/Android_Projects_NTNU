package com.example.sjur.imt3673_lab4_sss;

import android.content.SharedPreferences;
import android.os.Bundle;

import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.sql.Timestamp;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentMessagesList extends Fragment {
    private String TAG = "LAB4_CHAT";
    private SharedPreferences settings;
    private int mLastMessagePos;

    private Button mSendButton;
    private EditText mEditText;

    private ListView messagesListView;
    private ArrayList<Message> messagesList = new ArrayList<>();
    private MessagesAdapter messagesAdapter;

    private FirebaseDatabase mDatabase;
    private DatabaseReference mDatabaseRefMsg;


    public FragmentMessagesList() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mDatabase = FirebaseDatabase.getInstance();
        mDatabaseRefMsg = mDatabase.getReference("messages");

        final View fragmentView = inflater.inflate(
                R.layout.messages_list_fragment,
                container,
                false);
        messagesListView = fragmentView.findViewById(R.id.lv_messages_list_view);

        messagesAdapter = new MessagesAdapter(getContext(), messagesList);
        messagesListView.setAdapter(messagesAdapter);

        updateMessagesList();

        settings = PreferenceManager.getDefaultSharedPreferences(getContext());
        mLastMessagePos = settings.getInt("last_message_seen", 0);

        mEditText = fragmentView.findViewById(R.id.tvMessagesListFragmentEditText);

        mSendButton = fragmentView.findViewById(R.id.btnMessagesListFragmentSendButton);
        mSendButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String message = mEditText.getText().toString();

                //  validate the message
                if (message.isEmpty() || message.equalsIgnoreCase("") || message.length() < 1) {
                    Toast.makeText(getActivity(), R.string.createMessageShort,
                            Toast.LENGTH_LONG).show();
                    Log.v(TAG, "too short message");
                } else if (message.length() > 256) {
                    Toast.makeText(getActivity(), R.string.createMessageLong,
                            Toast.LENGTH_LONG).show();
                    Log.v(TAG, "too long message");
                } else {
                    String msgUsername = settings.getString("username", null);
                    Timestamp timestamp = new Timestamp(System.currentTimeMillis());

                    //  saving the new message to the online db
                    Message messageObj = new Message(msgUsername, timestamp.getTime(), message);
                    mDatabaseRefMsg.push().setValue(messageObj);
                    mEditText.setText("");
                }
            }
        });
        return fragmentView;
    }

    private void updateMessagesList() {

        // Attach a listener to read the data at messages reference
        mDatabaseRefMsg.orderByChild("date").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                //  Resetting the messagesList to avoid duplicates
                messagesList.clear();

                Message msg;
                for(DataSnapshot ds: dataSnapshot.getChildren()) {
                    msg = ds.getValue(Message.class);
                    if (msg.getTimestamp() != null && msg.getUsername() != null && msg.getMessage() != null) {
                        messagesList.add(msg);
                    }
                }

                //  storing position of the last message read
                mLastMessagePos = messagesList.size() - 1;
                SharedPreferences.Editor editor = settings.edit();
                editor.putInt("last_message_seen", mLastMessagePos);
                editor.apply();

                messagesAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("MessagesFragment: The read from messages failed: " + databaseError.getCode());
            }
        });
    }
}
