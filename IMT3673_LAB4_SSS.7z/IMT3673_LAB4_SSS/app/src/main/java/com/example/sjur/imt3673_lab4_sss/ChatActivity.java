package com.example.sjur.imt3673_lab4_sss;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

/**
 * The first and main activity of the app.
 *
 * Code in the project is somewhat simplified because of the "Assumed unique username" in the
 * description.
 *
 * Tutorials/Guides used:
 * http://www.gadgetsaint.com/android/create-viewpager-tabs-android/#.WrZ0dYjwaUl
 */

public class ChatActivity extends AppCompatActivity {

    private String TAG = "LAB4_CHAT";
    private final int NICKNAME_MAX_LENGTH = 35;
    private String mUserNickname;
    private String mRefreshRate;
    private PendingIntent backgroundServiceIntent;
    private AlarmManager alarmMan;

    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;

    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private DatabaseReference mDatabase;

    private ViewPager mViewPager;
    private TabLayout mTabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat_activity);

        mViewPager = (ViewPager) findViewById(R.id.vpChatActViewPager);
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new FragmentMessagesList(), "Messages");
        adapter.addFragment(new FragmentFriendsList(), "Friends");
        mViewPager.setAdapter(adapter);

        mTabLayout = (TabLayout) findViewById(R.id.tabChatActTabLayout);
        mTabLayout.setupWithViewPager(mViewPager);
        mTabLayout.getTabAt(0).setIcon(R.drawable.ic_forum_black_48dp);
        mTabLayout.getTabAt(1).setIcon(R.drawable.ic_supervisor_account_black_48dp);

        //  get the shared instance of the Firebase object
        mAuth = FirebaseAuth.getInstance();
        mUser = mAuth.getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        //Initializing default/saved values
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);

        //  get defaultSharePreferences
        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        editor = preferences.edit();
        mUserNickname = preferences.getString("username", null);

        //  check if the user is logged in, otherwise create a new anonymous user
        if (mUser == null) {
            createUser();
        }

        //  check if the user has a nickname, otherwise show alertdialog to create one
        if (mUserNickname == null) {
            createUsername();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        //  Activity with the chat is active, stop background service
        if (this.backgroundServiceIntent != null) {
            alarmMan = (AlarmManager)getSystemService(Service.ALARM_SERVICE);
            if (alarmMan != null) {
                Log.v(TAG, "BackgroundService canceled");
                alarmMan.cancel(this.backgroundServiceIntent);
            }
        }
    }

    @Override
    protected void onPause() {

        //  Activity with the chat is not active, start background service
        mRefreshRate = preferences.getString("pref_refresh_frequency", "10");
        startBackgroundService(Integer.parseInt(mRefreshRate));
        //startBackgroundService(Integer.parseInt("1"));
        Log.v(TAG, "BackgroundService started with refreshrate: " + mRefreshRate);

        super.onPause();
    }

    /**
     * Showing the alert for new users to choose a nickname, and then creates a new user(with
     * anonymous authentication). Finally saves the username to local sharedPreferences.
     * If they click the cancel button the activity closes.
     *
     * Basics of alerts from here: https://stackoverflow.com/questions/43513919/android-alert-dialog-with-one-two-and-three-buttons
     */
    public void createUsername() {

        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.alertChatActTitle);
        builder.setCancelable(false);

        //  create the input for username and fill with random default username
        final EditText etUsername= new EditText(this);
        etUsername.setInputType(InputType.TYPE_CLASS_TEXT);
        etUsername.setText(randomUsername());
        builder.setView(etUsername);

        // add the buttons
        builder.setPositiveButton(R.string.alertChatActPositiveButton, null);
        builder.setNegativeButton(R.string.alertChatActNegativeButton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                //  Close app
                finish();
            }
        });

        //  TODO: overwrite onBackPressed = finish()?

        // create the alert dialog
        final AlertDialog dialog = builder.create();

        /*  override the default button positive listener, for adding validation without recreating
            the dialog multiple times.
            From Daniel Nugent/Tom Bollwitt's answer: https://stackoverflow.com/questions/2620444/how-to-prevent-a-dialog-from-closing-when-a-button-is-clicked
        */
        Log.v(TAG, "before overriding positive listener");
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(DialogInterface dialogInterface) {

                Button button = ((AlertDialog) dialog).getButton(AlertDialog.BUTTON_POSITIVE);
                button.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        Log.v(TAG, "Positive Dialogbutton clicked");

                        //  Get the entered username and validate it
                        String inputUsernameText = etUsername.getText().toString().trim();
                        if (inputUsernameText.isEmpty() || inputUsernameText.equalsIgnoreCase("")) {
                            Toast.makeText(ChatActivity.this, R.string.alertChatActEmptyUsername,
                                    Toast.LENGTH_LONG).show();
                        } else if (inputUsernameText.length() > NICKNAME_MAX_LENGTH) {
                            Toast.makeText(ChatActivity.this, R.string.alertChatActTooLongUsername,
                                    Toast.LENGTH_LONG).show();
                        } else {
                            Log.v(TAG, "Positive Dialogbutton clicked: username validated");

                            //  check if user has been anonymously authenticated
                            mUser = mAuth.getCurrentUser();
                            if (mUser == null) {
                                Toast.makeText(ChatActivity.this, R.string.createUsernameFailed,
                                        Toast.LENGTH_LONG).show();
                            } else {
                                editor.putString("username", inputUsernameText);
                                editor.apply();

                                //  save username to db
                                User user = new User(inputUsernameText);
                                String uId = "user-"+inputUsernameText;

                                mDatabase.child("users").child(uId).setValue(user);

                                //Dismiss once everything is OK.
                                dialog.dismiss();

                            }

                        }
                    }
                });
            }
        });
        dialog.show();
    }

    /**
     * Unused method, seems to be needed for anonymous authentication
     * @param user  FirebaseUser object
     */
    public void updateUI(FirebaseUser user) {

        //  needed for the anonymous auth to not show error? Not used
    }

    /**
     * Creates a new anonymous user
     */
    private void createUser() {
        //  create a new user and then save the username to shared prefs
        mAuth.signInAnonymously()
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInAnonymously:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "signInAnonymously:failure", task.getException());
                            Toast.makeText(ChatActivity.this, R.string.createAnonAuthUserFailed,
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }
                    }
                });
    }

    /**
     * Mehtod for generating a 10 characters long random username.
     * @return  String  The random username to return.
     *
     * Inspired from bennettaur's answer: https://stackoverflow.com/questions/12116092/android-random-string-generator
     */
    @NonNull
    public static String randomUsername() {
        Random generator = new Random();
        StringBuilder randomStringBuilder = new StringBuilder();
        char tempChar;
        for (int i = 0; i < 10; i++){
            tempChar = (char) (generator.nextInt(96) + 32);
            randomStringBuilder.append(tempChar);
        }
        return randomStringBuilder.toString();
    }

    /**
     * Adapter for the viewpager using FragmentPagerAdapter
     */
    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    //  Adding the actionbar and functions
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Handle item selection, add more cases for more menu items
        switch (item.getItemId()) {
            case R.id.menu_settings:
                Intent intent = new Intent(this, SettingsActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void startBackgroundService(int minutes) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(calendar.MINUTE, minutes);

        Intent intent = new Intent(this, BackgroundService.class);
        this.backgroundServiceIntent = PendingIntent.getService(
                this,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
        );

        alarmMan = (AlarmManager) getSystemService(Service.ALARM_SERVICE);
        if (alarmMan != null) {
            alarmMan.setRepeating(
                    alarmMan.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    minutes * 1000,
                    this.backgroundServiceIntent
            );
        }
    }
}