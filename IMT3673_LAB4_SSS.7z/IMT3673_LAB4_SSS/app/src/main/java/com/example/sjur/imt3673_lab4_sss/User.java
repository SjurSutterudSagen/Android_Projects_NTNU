package com.example.sjur.imt3673_lab4_sss;

/**
 * User class/model
 */
public class User {
    private String username;

    public User() {
        //  Empty constructor
    }

    public User(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
