package com.example.sjur.imt3673_lab4_sss;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

public class MessagesAdapter2 extends BaseAdapter {
    private String TAG = "LAB4_CHAT";
    private static ArrayList<Message> messageArrayList;
    private LayoutInflater mInflater;

    public MessagesAdapter2(Context ctx, ArrayList<Message> messages) {
        messageArrayList = messages;
        mInflater = LayoutInflater.from(ctx);
    }

    @Override
    public int getCount() {
        return messageArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return messageArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    //  View lookup cache
    private static class ViewHolder {
        TextView itemAuthor;
        TextView itemDate;
        TextView itemMessage;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // Check if an existing view is being reused, otherwise inflate the view
        ViewHolder viewHolder;
        if (convertView == null) {

            //  no view to re-use, inflate a new one
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.message_item, parent, false);
            viewHolder.itemAuthor = (TextView) convertView.findViewById(R.id.message_item_author);
            viewHolder.itemDate = (TextView) convertView.findViewById(R.id.message_item_date);
            viewHolder.itemMessage = (TextView) convertView.findViewById(R.id.message_item_content);

            //  cache the viewHolder object inside the new view
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        //  Populate the messages data in the new viewHolder object and into the template view
        Date date = new Date(messageArrayList.get(position).getTimestamp());
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.UK);

        viewHolder.itemAuthor.setText(messageArrayList.get(position).getUsername());
        viewHolder.itemDate.setText(sdf.format(date));
        viewHolder.itemMessage.setText(messageArrayList.get(position).getMessage());

        //  return the completed view to render on screen
        return convertView;
    }
}
