package com.example.sjur.imt3673_lab4_sss;

/**
 * The class for the messages
 */
class Message {
    public String username;
    public Long timestamp;
    public String message;

    public Message() {
        //  empty constructor
    }

    public Message(String username, Long timestamp, String message) {
        this.username = username;
        this.timestamp = timestamp;
        this.message = message;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
