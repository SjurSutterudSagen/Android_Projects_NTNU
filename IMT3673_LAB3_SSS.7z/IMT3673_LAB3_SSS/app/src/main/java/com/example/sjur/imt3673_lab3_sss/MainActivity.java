package com.example.sjur.imt3673_lab3_sss;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

/**
 * Example activity that contains a view that reads accelerometer sensor input and
 * translates a circle based on the changes.
 * Heavily based on: https://gist.github.com/Jawnnypoo/fcceea44be628c2d5ae1
 *
 */
public class MainActivity extends Activity implements SensorEventListener {

    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private Vibrator mVibrator;
    private ToneGenerator mToneGenerator;
    private AnimatedView mAnimatedView = null;

    /**
     * Initialize needed data, set sensor manager and sets view
     *
     * @param savedInstanceState    The saved instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        mToneGenerator = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
        mVibrator = (Vibrator) this.getSystemService(VIBRATOR_SERVICE);

        mAnimatedView = new AnimatedView(this);

        //Set our content to a view, not like the traditional setting to a layout
        setContentView(mAnimatedView);
    }

    /**
     * Called when activity is started
     */
    @Override
    protected void onResume() {
        super.onResume();

        //  Registering event listener
        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_GAME);
    }

    /**
     * Called when acticity is paused
     */
    @Override
    protected void onPause() {
        super.onPause();

        //  Unregistering event listener
        mSensorManager.unregisterListener(this);
    }

    /**
     * Mandatory, but unneeded
     *
     * @param arg0  Argument0
     * @param arg1  Argument1
     */
    @Override
    public void onAccuracyChanged(Sensor arg0, int arg1) { }

    /**
     * Fires whenever there is a change in sensors
     *
     * @param event The sensor event data
     */
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            mAnimatedView.onSensorEvent(event);
        }
    }

    /**
     * Draws the view and updates ball position
     */
    public class AnimatedView extends View {

        //  Background border
        private Rect background;
        private Paint backgroundPaint;

        //  Screen dimensions
        private int displayW;
        private int displayH;

        private int margin = 75;
        private int ballMargin = margin + 20;

        //  Ball data
        private static final int CIRCLE_RADIUS = 25;
        private Paint ballPaint;
        private int ballX;
        private int ballY;
        private int viewWidth;
        private int viewHeight;

        /**
         * Get screen size, set background border and game ball
         *
         * @param context   The context
         */
        public AnimatedView(Context context) {
            super(context);
            getUsableDisplaySize();

            viewHeight = displayH;
            viewWidth = displayW;

            //  The styling for the background border
            background = new Rect(margin, margin, displayW - margin, displayH - margin);
            backgroundPaint = new Paint();
            backgroundPaint.setColor(Color.BLACK);
            backgroundPaint.setStrokeWidth(40);
            backgroundPaint.setStyle(Paint.Style.STROKE);

            //  Set ball initial position to centered
            ballX = viewWidth/2;
            ballY = viewHeight/2;

            ballPaint = new Paint();
            ballPaint.setColor(Color.MAGENTA);
        }

        /**
         * Get the "playingfield"
         *
         * Based on: https://androidkennel.org/android-sensors-game-tutorial/
         */
        private void getUsableDisplaySize() {
            Point size = new Point();
            Display display = getWindowManager().getDefaultDisplay();
            display.getSize(size);
            displayW = size.x;
            displayH = size.y;
        }

        /**
         * Update view sizes on change.
         * @param w     int The new width
         * @param h     int The new height
         * @param oldW  int The old width
         * @param oldH  int The old height
         */
        @Override
        protected void onSizeChanged(int w, int h, int oldW, int oldH) {
            super.onSizeChanged(w, h, oldW, oldH);
            viewWidth = w - ballMargin;
            viewHeight = h - ballMargin;
        }

        /**
         * Update ball's position on sensor change
         * @param event The sensor event data
         */
        public void onSensorEvent (SensorEvent event) {
            ballX = ballX - (int) event.values[0];
            ballY = ballY + (int) event.values[1];

            //Make sure we do not draw outside the bounds of the border.
            //So the max values we can draw to are the bounds + the size of the circle +/- 100 for
            // the "bounce" of the ball

            //  use ballMargin to stay within the background border
            if (ballX <= ballMargin + CIRCLE_RADIUS) {
                ballX = ballMargin + CIRCLE_RADIUS + 100;
                playSoundAndVibrate();
            }

            if (ballY <= ballMargin + CIRCLE_RADIUS) {
                ballY = ballMargin + CIRCLE_RADIUS + 100;
                playSoundAndVibrate();
            }

            if (ballX >= viewWidth - CIRCLE_RADIUS) {
                ballX = viewWidth - CIRCLE_RADIUS - 100;
                playSoundAndVibrate();
            }

            if (ballY >= viewHeight - CIRCLE_RADIUS) {
                ballY = viewHeight - CIRCLE_RADIUS - 100;
                playSoundAndVibrate();
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            canvas.drawRect(background, backgroundPaint);
            canvas.drawCircle(ballX, ballY, CIRCLE_RADIUS, ballPaint);
            //We need to call invalidate each time, so that the view continuously draws
            invalidate();
        }
    }

    /**
     * Vibrate phone and play tone
     */
    private void playSoundAndVibrate() {
        this.mVibrator.vibrate(100);
        this.mToneGenerator.startTone(ToneGenerator.TONE_DTMF_0, 100);
    }

}